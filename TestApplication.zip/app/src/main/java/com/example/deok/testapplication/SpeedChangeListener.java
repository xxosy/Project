package com.example.deok.testapplication;

public interface SpeedChangeListener {

    public void onSpeedChanged(float newSpeedValue);

}