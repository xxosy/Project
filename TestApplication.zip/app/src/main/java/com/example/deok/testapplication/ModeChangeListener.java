package com.example.deok.testapplication;

/**
 * Created by YoungWon on 2015-03-17.
 */
public interface ModeChangeListener {
    public void onModeChanged(boolean state);
}
